#!/usr/bin/python

'''
cluster_node.py 
Node to cluster lines for object detection


Bryant Pong / Micah Corah      
CSCI-4962
'''

import numpy as np
import rospy
